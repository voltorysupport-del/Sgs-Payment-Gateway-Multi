# Local synthetic dashboard preview

This frontend-only preview uses the existing React interface with local synthetic API responses. It does not start Express, connect to PostgreSQL, read a database URL/key, run migrations, or contact Render/providers. The demo launcher is separate from the application and production build. Backend authentication and authorization are unchanged. No production feature gate is enabled.

## Windows ZIP (no Git commands)

1. Install **Node.js 24 LTS** if it is not already installed.
2. Extract the entire supplied preview ZIP into a normal folder. Do not run it inside the ZIP viewer.
3. Double-click **Preview-Dashboard.cmd**. The first run downloads locked frontend dependencies from npm; keep the window open.
4. Open **http://127.0.0.1:4173/dashboard/** in your browser.
5. Enter username **demo** and password **demo-preview-only**, then click **Sign in securely**. These are dummy demonstration values; any inputs meeting the existing form length checks work. Never enter real credentials.
6. Press **Ctrl+C** in the preview window when finished.

The launcher uses CMD and Node, not PowerShell or administrator rights. If port 4173 is already occupied, it stops rather than choosing another address. It listens only on 127.0.0.1; no tunnel or public hosting is used. An existing cloud preview cannot be opened through your laptop's localhost: run the package on your laptop first.

## Existing repository checkout

From the repository folder, run `npm ci` once, then `npm run preview:dashboard`. Node.js 24 is recommended. The standalone ZIP uses a smaller, pinned frontend-only dependency set; it contains no backend, credentials, environment files, database tooling or Git history.

## What to inspect

- Login layout, sign-out, and navigation.
- Overview summary cards and payment table.
- Payment history with 24 synthetic records, ten per page; next/previous paging and status/currency filters.
- Payment details and pending/succeeded/failed/cancelled badges.
- System status layout (all status values are simulated).
- Narrow/mobile layouts, keyboard focus and navigation.

This is a visual demonstration, not an authentication/security test or staging connection test. Demo sign-in is deliberately simulated; sessions last only while the local preview runs. Refreshing retains the local demo cookie; signing out removes it. There are no payment creation/completion actions. Data never changes or persists. Database-reachable and simulator status labels are fixtures, not live checks. Network/server error and real expiry behavior are covered by project tests, not demonstrated here.

Changes are isolated on `feature/local-dashboard-preview` for review. No merge, deployment or publication to GitHub is implied by preparing the local package.
