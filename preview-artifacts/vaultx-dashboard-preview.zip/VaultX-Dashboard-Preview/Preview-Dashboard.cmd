@echo off
setlocal
cd /d "%~dp0"
node -e "if(process.versions.node.split('.')[0]!=='24'){process.stderr.write('Please install Node.js 24 LTS, then double-click this file again.\n');process.exit(1)}"
if errorlevel 1 goto failed
if exist node_modules\.package-lock.json goto launch
call npm ci --no-audit --no-fund
if errorlevel 1 goto failed
:launch
echo Open http://127.0.0.1:4173/dashboard/ in your browser.
echo LOCAL DEMO ONLY. Use demo / demo-preview-only. Never enter real credentials.
call npm run preview:dashboard
if errorlevel 1 goto failed
exit /b 0
:failed
echo Preview did not start. No database or real payment service was contacted.
pause
exit /b 1
