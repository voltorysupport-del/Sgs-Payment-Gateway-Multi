/* global process */
// Standalone development launcher. Never imported by the application or build.
import { randomUUID } from 'node:crypto';
import { fileURLToPath, URL } from 'node:url';
import { createServer } from 'vite';

const host = '127.0.0.1';
const port = 4173;
const origin = `http://${host}:${port}`;
process.env.LIVE_MODE_ENABLED = 'false';
process.env.DASHBOARD_ENABLED = 'false';
process.env.DASHBOARD_BFF_ENABLED = 'false';
process.env.ALLOWED_PROVIDERS = 'simulator';
const sessions = new Set();
const payments = Array.from({ length: 24 }, (_, index) => ({
  id: `00000000-0000-4000-8000-${String(index + 1).padStart(12, '0')}`,
  amountMinor: [100, 2499, 7500, 12000][index % 4],
  currency: ['EUR', 'USD', 'GBP'][index % 3],
  status: ['succeeded', 'pending', 'failed', 'cancelled'][index % 4],
  provider: 'simulator',
  createdAt: new Date(Date.UTC(2026, 9, 26, 12, 0) - index * 3600000).toISOString(),
  updatedAt: new Date(Date.UTC(2026, 9, 26, 12, 5) - index * 3600000).toISOString(),
}));
const server = await createServer({
  configFile: fileURLToPath(new URL('../frontend/vite.config.ts', import.meta.url)),
  server: {
    host,
    port,
    strictPort: true,
    open: false,
    cors: false,
    allowedHosts: [host],
    fs: {
      strict: true,
      allow: [
        fileURLToPath(new URL('../frontend', import.meta.url)),
        fileURLToPath(new URL('../node_modules', import.meta.url)),
      ],
    },
  },
  plugins: [
    {
      name: 'local-synthetic-dashboard-only',
      apply: 'serve',
      transformIndexHtml(html) {
        return html.replace(
          '<body>',
          `<body><aside role="note" style="padding:12px;background:#342907;color:#fff;text-align:center;font:14px system-ui">LOCAL DEMO · Synthetic data only · Sign in with username <b>demo</b> and password <b>demo-preview-only</b>. Never enter real credentials.</aside>`,
        );
      },
      configureServer(vite) {
        vite.middlewares.use((req, res, next) => {
          const send = (status, value) => {
            res.writeHead(status, {
              'Content-Type': 'application/json',
              'Cache-Control': 'no-store',
            });
            res.end(JSON.stringify(value));
          };
          if (
            req.headers.host !== `${host}:${port}` ||
            (req.headers.origin && req.headers.origin !== origin)
          ) {
            send(403, { error: 'Local preview only.' });
            return;
          }
          const url = new URL(req.url, origin);
          if (!url.pathname.startsWith('/dashboard-api')) return next();
          // No network forwarding, DB imports, credential logging or persistent state.
          const cookie = /(?:^|;\s*)vaultx_demo=([a-f0-9-]+)/.exec(req.headers.cookie ?? '')?.[1];
          const signedIn = sessions.has(cookie);
          const route = url.pathname;
          if (route === '/dashboard-api/auth/csrf' && req.method === 'GET') {
            send(200, { csrfToken: '0'.repeat(64) });
          } else if (route === '/dashboard-api/auth/login' && req.method === 'POST') {
            // Consume/discard input with a hard bound; no passwords are inspected/stored.
            let size = 0;
            req.on('data', (chunk) => {
              size += chunk.length;
              if (size > 4096) req.destroy();
            });
            req.on('end', () => {
              if (size > 4096) return;
              if (cookie) sessions.delete(cookie);
              if (sessions.size >= 100) sessions.clear();
              const id = randomUUID();
              sessions.add(id);
              res.setHeader('Set-Cookie', `vaultx_demo=${id}; HttpOnly; SameSite=Strict; Path=/`);
              send(200, { authenticated: true, csrfToken: '0'.repeat(64) });
            });
          } else if (!signedIn) {
            send(401, { error: 'Demo sign-in required.' });
          } else if (route === '/dashboard-api/auth/logout' && req.method === 'POST') {
            sessions.delete(cookie);
            res.setHeader(
              'Set-Cookie',
              'vaultx_demo=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0',
            );
            res.writeHead(204, { 'Cache-Control': 'no-store' });
            res.end();
          } else if (req.method !== 'GET') {
            send(405, { error: 'Demo read only.' });
          } else if (route === '/dashboard-api/auth/me') {
            send(200, {
              user: { id: '00000000-0000-4000-8000-000000000100', username: 'demo.viewer' },
              operator: { id: '00000000-0000-4000-8000-000000000200' },
              role: 'viewer',
            });
          } else if (route === '/dashboard-api/status') {
            send(200, {
              status: 'ok',
              gateway: 'ok',
              database: 'reachable',
              provider: 'simulator',
              realPaymentsEnabled: false,
            });
          } else if (route === '/dashboard-api/payments') {
            const offset = Number(url.searchParams.get('offset') ?? '0');
            const limit = Number(url.searchParams.get('limit') ?? '10');
            if (!Number.isInteger(offset) || offset < 0 || offset > 10000 || limit !== 10) {
              send(400, { error: 'Invalid demo pagination.' });
              return;
            }
            const filtered = payments.filter(
              (p) =>
                (!url.searchParams.get('status') || p.status === url.searchParams.get('status')) &&
                (!url.searchParams.get('currency') ||
                  p.currency === url.searchParams.get('currency')),
            );
            send(200, {
              payments: filtered.slice(offset, offset + limit),
              pagination: { limit, offset, hasMore: offset + limit < filtered.length },
            });
          } else {
            const payment = payments.find((p) => route === '/dashboard-api/payments/' + p.id);
            send(payment ? 200 : 404, payment ?? { error: 'Demo payment not found.' });
          }
        });
      },
    },
  ],
});
await server.listen();
process.stdout.write(
  `Local synthetic dashboard: ${origin}/dashboard/\nNo database or real API is connected. Close this window or press Ctrl+C to stop.`,
);
