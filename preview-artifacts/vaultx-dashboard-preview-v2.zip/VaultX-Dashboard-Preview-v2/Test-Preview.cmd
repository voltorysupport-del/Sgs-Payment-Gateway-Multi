@echo off
setlocal
cd /d "%~dp0"
echo Close the preview server before running these isolated local smoke tests.
node --test tests\smoke.test.mjs
pause
