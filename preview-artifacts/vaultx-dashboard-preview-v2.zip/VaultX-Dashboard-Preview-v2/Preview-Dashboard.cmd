@echo off
setlocal
cd /d "%~dp0"
node -e "if(process.versions.node.split('.')[0]!=='24'){process.stderr.write('Install Node.js 24 LTS, then double-click this file again.\n');process.exit(1)}"
if errorlevel 1 goto failed
echo Open http://127.0.0.1:4174/ in your browser.
echo LOCAL PREVIEW V2. All data and actions are simulated. Never enter real credentials.
node scripts\demo-server.mjs
if errorlevel 1 goto failed
exit /b 0
:failed
echo Preview did not start. No real gateway or database was contacted.
pause
exit /b 1
