// Automated UI validation only. Playwright is supplied outside the runtime ZIP.
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import path from "node:path";
import { startPreview } from "../scripts/demo-server.mjs";
const tools = process.env.VAULTX_PREVIEW_BROWSER_TOOLS;
if (!tools)
  throw new Error(
    "Browser smoke requires externally installed Playwright tools.",
  );
const { chromium } = createRequire(path.join(tools, "package.json"))(
  "playwright",
);
const server = await startPreview();
let browser;
try {
  browser = await chromium.launch({
    headless: true,
    ...(process.env.VAULTX_CHROMIUM_EXECUTABLE
      ? { executablePath: process.env.VAULTX_CHROMIUM_EXECUTABLE }
      : {}),
    ...(process.platform === "linux" ? { args: ["--no-sandbox"] } : {}),
  });
  const context = await browser.newContext({
      viewport: { width: 1440, height: 1000 },
    }),
    page = await context.newPage();
  const errors = [],
    external = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await context.route("**/*", (route) => {
    const url = new URL(route.request().url());
    if (url.origin !== "http://127.0.0.1:4174") {
      external.push(url.origin);
      return route.abort();
    }
    return route.continue();
  });
  page.on("dialog", (dialog) => dialog.accept());
  await page.goto("http://127.0.0.1:4174/");
  await page
    .getByRole("link", { name: "Open owner management →", exact: true })
    .click();
  await page
    .getByRole("heading", { name: "Owner overview", exact: true })
    .waitFor();
  const nav = page.getByRole("navigation", { name: "Owner navigation" });
  await nav.getByRole("link", { name: "Operators", exact: true }).click();
  await page.getByRole("heading", { name: "Operators", exact: true }).waitFor();
  await page
    .getByRole("button", { name: "Inspect demo-client-02", exact: true })
    .click();
  await page.getByLabel("Display name").fill("Demo Local Updated Client");
  let response = page.waitForResponse(
    (r) => r.request().method() === "PATCH" && r.url().endsWith("000000000002"),
  );
  await page
    .getByRole("button", { name: "Save display name", exact: true })
    .click();
  assert.equal((await response).status(), 200);
  await page.getByLabel("Display name").waitFor();
  response = page.waitForResponse(
    (r) => r.request().method() === "PATCH" && r.url().endsWith("000000000002"),
  );
  await page
    .getByRole("button", { name: "Suspend client", exact: true })
    .click();
  assert.equal((await (await response).json()).operator.status, "suspended");
  response = page.waitForResponse(
    (r) => r.request().method() === "PATCH" && r.url().endsWith("000000000002"),
  );
  await page
    .getByRole("button", { name: "Reactivate client", exact: true })
    .click();
  assert.equal((await (await response).json()).operator.status, "active");
  await nav.getByRole("link", { name: "Client accounts", exact: true }).click();
  await page
    .getByRole("button", { name: "Inspect demo-client-03", exact: true })
    .click();
  await page
    .getByRole("heading", { name: "Retained client memberships", exact: true })
    .waitFor();
  await nav
    .getByRole("link", { name: "Team and permissions", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Inspect demo-client-03", exact: true })
    .click();
  await page
    .getByRole("heading", {
      name: "Withdraw existing client read entitlement",
      exact: true,
    })
    .waitFor();
  response = page.waitForResponse(
    (r) =>
      r.request().method() === "POST" &&
      r.url().endsWith("client.payments.read/withdraw"),
  );
  await page
    .getByRole("button", { name: "Withdraw payment read", exact: true })
    .click();
  assert.equal((await response).status(), 200);
  await nav.getByRole("link", { name: "Audit activity", exact: true }).click();
  await page
    .getByRole("heading", { name: "Privileged activity", exact: true })
    .waitFor();
  await page
    .getByRole("cell", { name: "entitlements.withdraw", exact: true })
    .first()
    .waitFor();
  await page
    .getByRole("link", { name: "Payment dashboard", exact: true })
    .click();
  await page
    .getByRole("heading", { name: "Welcome back", exact: true })
    .waitFor();
  await page.getByLabel("Username", { exact: true }).fill("demo");
  await page.getByLabel("Password", { exact: true }).fill("demo-preview-only");
  await page.getByRole("button", { name: /Sign in securely/ }).click();
  await page.getByRole("heading", { name: "Overview", exact: true }).waitFor();
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: /Payments/ })
    .click();
  await page
    .getByRole("link", { name: /View details/ })
    .first()
    .click();
  await page
    .getByRole("heading", { name: "Payment details", exact: true })
    .waitFor();
  await page
    .getByRole("navigation", { name: "Main navigation" })
    .getByRole("link", { name: /System status/ })
    .click();
  await page
    .getByRole("heading", { name: "System status", exact: true })
    .waitFor();
  await page.setViewportSize({ width: 390, height: 844 });
  await page
    .getByRole("link", { name: "Owner management", exact: true })
    .click();
  await page
    .getByRole("heading", { name: "Owner overview", exact: true })
    .waitFor();
  assert.equal(errors.length, 0, errors.join("\n"));
  assert.equal(external.length, 0, "No external browser requests allowed.");
  console.log(
    "PASS: all five owner screens; metadata, suspension/reactivation, withdrawal, audit; payment login/overview/history/detail/status; mobile; no external requests.",
  );
} finally {
  await browser?.close();
  server.closeAllConnections();
  await new Promise((resolve) => server.close(resolve));
}
