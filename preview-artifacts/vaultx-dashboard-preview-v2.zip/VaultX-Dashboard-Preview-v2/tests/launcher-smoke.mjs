// Executes the actual Windows CMD launcher; no PowerShell or policy changes.
import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
const cwd = fileURLToPath(new URL("../", import.meta.url));
const windows = process.platform === "win32";
const child = spawn(
  windows ? "cmd.exe" : process.execPath,
  windows ? ["/d", "/c", "Preview-Dashboard.cmd"] : ["scripts/demo-server.mjs"],
  { cwd, shell: false, stdio: ["ignore", "pipe", "pipe"] },
);
let output = "",
  error = "",
  ended = false;
child.stdout.on("data", (data) => {
  output = (output + data).slice(-10000);
});
child.stderr.on("data", (data) => {
  error = (error + data).slice(-10000);
});
child.on("exit", () => {
  ended = true;
});
try {
  const deadline = Date.now() + 15000;
  while (
    !output.includes("VaultX Pay PREVIEW V2") &&
    Date.now() < deadline &&
    !ended
  )
    await new Promise((resolve) => setTimeout(resolve, 50));
  assert.equal(ended, false, "Launcher exited before server became ready.");
  assert.match(output, /VaultX Pay PREVIEW V2/);
  const response = await fetch("http://127.0.0.1:4174/", {
    signal: AbortSignal.timeout(3000),
  });
  assert.equal(response.status, 200);
  assert.match(await response.text(), /ALL DATA AND ACTIONS SIMULATED/);
  assert.equal(error, "");
  console.log(
    "PASS: actual " +
      (windows ? "Windows CMD" : "Node") +
      " launcher started and served the loopback home page.",
  );
} finally {
  if (windows && child.pid)
    spawnSync("taskkill.exe", ["/PID", String(child.pid), "/T", "/F"], {
      stdio: "ignore",
      shell: false,
    });
  else child.kill("SIGTERM");
  if (!ended)
    await new Promise((resolve) => {
      child.once("exit", resolve);
      setTimeout(resolve, 3000).unref();
    });
}
