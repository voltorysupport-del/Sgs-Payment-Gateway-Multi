import { before, after, test } from "node:test";
import assert from "node:assert/strict";
import { startPreview } from "../scripts/demo-server.mjs";
import { id } from "../scripts/demo-state.mjs";
let server, ownerCookie, csrf;
const base = "http://127.0.0.1:4174";
const call = (route, method = "GET", data, headers = {}) =>
  fetch(base + route, {
    method,
    headers: {
      Origin: base,
      ...(data ? { "Content-Type": "application/json" } : {}),
      ...headers,
    },
    ...(data ? { body: JSON.stringify(data) } : {}),
  });
before(async () => {
  server = await startPreview();
});
after(async () => {
  server?.closeAllConnections();
  await new Promise((resolve) => server?.close(resolve));
});
test("binds only loopback and serves both built apps with demo labels and local-only CSP", async () => {
  assert.equal(server.address().address, "127.0.0.1");
  for (const route of ["/", "/dashboard/", "/owner/"]) {
    const r = await call(route);
    assert.equal(r.status, 200);
    const html = await r.text();
    assert.match(html, /ALL DATA AND ACTIONS SIMULATED/);
    assert.equal(r.headers.get("cache-control"), "no-store");
    assert.match(
      r.headers.get("content-security-policy"),
      /connect-src 'self'/,
    );
  }
  assert.equal((await call("/owner-api/clients")).status, 401);
  assert.equal((await call("/payments", "POST", {})).status, 405);
  assert.equal((await call("/.env")).status, 404);
  assert.equal(
    (
      await call("/owner-api/clients", "GET", undefined, {
        Origin: "https://example.invalid",
      })
    ).status,
    403,
  );
});
test("owner synthetic access reads every management contract with bounded pages", async () => {
  const access = await call("/demo/owner");
  ownerCookie = access.headers.get("set-cookie").split(";")[0];
  const headers = { Cookie: ownerCookie };
  csrf = (
    await (await call("/owner-api/auth/csrf", "GET", undefined, headers)).json()
  ).csrfToken;
  assert.equal(
    (await call("/owner-api/auth/me", "GET", undefined, headers)).status,
    200,
  );
  const first = await (
    await call(
      "/owner-api/clients?limit=20&offset=0",
      "GET",
      undefined,
      headers,
    )
  ).json();
  assert.equal(first.operators.length, 20);
  assert.equal(first.pagination.hasMore, true);
  const last = await (
    await call(
      "/owner-api/clients?limit=20&offset=20",
      "GET",
      undefined,
      headers,
    )
  ).json();
  assert.equal(last.operators.length, 5);
  assert.equal(last.pagination.hasMore, false);
  const members = await (
    await call(
      "/owner-api/clients/" + id(1) + "/members?limit=20&offset=0",
      "GET",
      undefined,
      headers,
    )
  ).json();
  assert.equal(members.members.length, 3);
  assert.equal(members.operatorId, id(1));
  assert.equal(
    (
      await call(
        "/owner-api/audit?limit=20&offset=0",
        "GET",
        undefined,
        headers,
      )
    ).status,
    200,
  );
});
test("local status, versions, withdrawal and audit mutate demo memory only", async () => {
  const headers = { Cookie: ownerCookie, "X-CSRF-Token": csrf },
    route = "/owner-api/clients/" + id(2);
  const changed = await call(
    route,
    "PATCH",
    { expectedVersion: 1, status: "suspended" },
    headers,
  );
  assert.equal(changed.status, 200);
  assert.equal((await changed.json()).operator.version, 2);
  assert.equal(
    (
      await call(
        route,
        "PATCH",
        { expectedVersion: 1, status: "active" },
        headers,
      )
    ).status,
    409,
  );
  assert.equal(
    (
      await call(
        route,
        "PATCH",
        { expectedVersion: 2, status: "active" },
        headers,
      )
    ).status,
    200,
  );
  const withdraw = await call(
    route + "/entitlements/client.payments.read/withdraw",
    "POST",
    { expectedVersion: 3 },
    headers,
  );
  assert.equal(withdraw.status, 200);
  assert.equal((await withdraw.json()).operator.version, 4);
  assert.equal(
    (
      await call(
        route + "/entitlements/client.payments.read/withdraw",
        "POST",
        { expectedVersion: 4 },
        headers,
      )
    ).status,
    409,
  );
  const audit = await (
    await call("/owner-api/audit?limit=20&offset=0", "GET", undefined, headers)
  ).json();
  assert.equal(audit.events[0].action, "entitlements.withdraw");
  assert.equal(audit.events[0].operatorId, id(2));
});
test("payment dashboard supports synthetic login, history, detail and simulator status without writes", async () => {
  const response = await call("/dashboard-api/auth/login", "POST", {
    username: "demo",
    password: "demo-preview-only",
  });
  const cookie = response.headers.get("set-cookie").split(";")[0],
    headers = { Cookie: cookie };
  const history = await (
    await call(
      "/dashboard-api/payments?limit=10&offset=0",
      "GET",
      undefined,
      headers,
    )
  ).json();
  assert.equal(history.payments.length, 10);
  assert.equal(history.payments[0].provider, "simulator");
  assert.equal(
    (
      await call(
        "/dashboard-api/payments/" + history.payments[0].id,
        "GET",
        undefined,
        headers,
      )
    ).status,
    200,
  );
  const status = await (
    await call("/dashboard-api/status", "GET", undefined, headers)
  ).json();
  assert.equal(status.realPaymentsEnabled, false);
  assert.equal(
    (await call("/dashboard-api/payments", "POST", {}, headers)).status,
    405,
  );
  assert.equal((await call("/demo/reset", "POST", {})).status, 200);
  assert.equal(
    (
      await call("/owner-api/clients", "GET", undefined, {
        Cookie: ownerCookie,
      })
    ).status,
    401,
  );
});
