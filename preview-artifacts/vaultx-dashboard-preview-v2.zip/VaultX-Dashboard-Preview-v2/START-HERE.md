# VaultX Pay Management Dashboard Preview v2

ALL DATA, ACCESS AND ACTIONS ARE SIMULATED. This is an isolated visual/interaction demo, not a gateway deployment or authentication test.

## Windows — no Git, npm, build or PowerShell commands

1. Install **Node.js 24 LTS** from https://nodejs.org/ if it is not already installed.
2. Download the GitHub Actions artifact. Right-click its ZIP and choose **Extract All**.
3. Inside, extract **vaultx-dashboard-preview-v2.zip** as well. Keep all extracted files together.
4. Open the **VaultX-Dashboard-Preview-v2** folder and double-click **Preview-Dashboard.cmd**. Keep that window open.
5. Open **http://127.0.0.1:4174/** in your normal browser.
6. Click **Open owner management** for automatic synthetic owner access, or **Open payment dashboard**.
7. For payment sign-in only, use username **demo**, password **demo-preview-only**. Never enter real credentials.
8. When finished, press **Ctrl+C** in the launcher window.

Runtime is completely offline after Node and the ZIP are installed. No dependency installation is needed. No administrator rights or PowerShell policy changes are required. If port 4174 is already in use, the tool stops; close a previous preview first. It never changes ports or binds to a public interface.

## Screens and actions

- Payment overview, history (34 simulated payments), pagination, filters, detail and system-status layout.
- Owner overview and bounded operator directory (25 fictional demo clients).
- Operators: choose **Inspect**, edit the display name, suspend or reactivate. Confirmations and versions behave like the UI contracts.
- Client accounts: inspect a client to view its three synthetic retained memberships.
- Team and permissions: inspect an active client and withdraw payment-read or status-read. Grants remain revoked when a client is reactivated. Unknown/stale versions are rejected.
- Audit activity: inspect simulated history and new local action records.
- Desktop, narrow/mobile layout, keyboard navigation and sign-out.

Use client 02 for status changes and client 03 for entitlement withdrawal to leave the payment viewer's client 01 unchanged. Withdrawing client 01 reads or suspending it deliberately makes its payment preview refuse access. **Reset disposable demo state** in the gold banner restores the initial fictional dataset; stopping/restarting also discards all changes. Reset affects only this process's synthetic data. No files or real records are changed.

After owner sign-out, click **Owner management** in the gold demo banner to enter a new synthetic demo session. This is not real login/MFA or a production recovery procedure.

## Isolation and limitations

The prebuilt React interfaces are from development merge **6348b6716fa3153d01902b8eaf8e891b9c8c9aad**. Production frontend/authentication source is unchanged. A standalone Node server serves only local static files and synthetic same-origin API responses, using uniquely named preview cookies that cannot authenticate to the real gateway.

There is no Express backend, PostgreSQL driver, database connection, API key, DPAPI delivery file, configuration loader, real authentication, external provider or real payment operation in the package. DATABASE_URL and real feature-gate settings are not used. No secrets are needed or requested. All “verified session” and “database reachable” labels inside the existing interface are simulated, as the persistent gold banner explains. No real management enrollment or credential provisioning is demonstrated.

State exists only in memory. Existing viewer-only memberships match the current application; account creation, role promotion, delegation, regrant and key-management actions are absent. Payment creation/completion is not offered. This demo is not proof of production authorization, MFA, database health or readiness.

## Included automated smoke tests

Close the running preview, then double-click **Test-Preview.cmd** for four dependency-free HTTP/state/integrity-boundary smoke tests. These create only local disposable memory state and stop their server afterward.

`tests/browser-smoke.mjs` additionally checks all five owner screens, local management actions, audit, payment dashboard and mobile rendering in real Chromium while blocking external requests. CI supplies Playwright separately; it is not needed for normal preview use. `tests/launcher-smoke.mjs` also executes the actual CMD launcher on native Windows CI. CI verifies the ZIP checksum and every manifest entry before and after testing.

`SOURCE.json` records provenance. `SHA256SUMS.json` records hashes of all included files except itself. The package contains third-party license notices. Nothing is deployed, merged or connected to Render by running it.
