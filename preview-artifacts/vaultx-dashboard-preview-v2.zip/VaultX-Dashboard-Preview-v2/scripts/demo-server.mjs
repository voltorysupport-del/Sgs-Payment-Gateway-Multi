// PREVIEW ONLY: synthetic APIs for prebuilt UI. Never imported by the gateway.
import http from "node:http";
import { randomBytes, randomUUID } from "node:crypto";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { createState, id, READS, OWNER, record } from "./demo-state.mjs";
const HOST = "127.0.0.1",
  PORT = 4174,
  ORIGIN = `http://${HOST}:${PORT}`;
const PUBLIC = path.resolve(
  fileURLToPath(new URL("../public/", import.meta.url)),
);
const cookieNames = ["vaultx_preview_v2_owner", "vaultx_preview_v2_client"];
const html = (body) =>
  `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>VaultX Pay Local Preview v2</title><link rel="stylesheet" href="/demo.css"><body>${body}</body></html>`;
const navigation = `<aside class="demo-banner" role="note"><b>LOCAL PREVIEW V2 — ALL DATA AND ACTIONS SIMULATED</b><br>No real authentication, API or database. “Verified” and health labels are demo fixtures.<nav><a href="/dashboard/">Payment dashboard</a> · <a href="/demo/owner">Owner management</a> · <a href="/">Instructions</a><form method="post" action="/demo/reset"><button>Reset disposable demo state</button></form></nav></aside>`;
const home = html(
  navigation +
    `<main class="demo-home"><h1>VaultX Pay · Management Preview v2</h1><p>Dark-blue interface from the reviewed merged application. Nothing connects to the real gateway.</p><h2>Choose a workspace</h2><p><a href="/demo/owner">Open owner management →</a> (automatic synthetic access; no real credentials)</p><p><a href="/dashboard/">Open payment dashboard →</a></p><p>Payment demo username: <b>demo</b> · password: <b>demo-preview-only</b>. Never enter real credentials.</p><p>Explore Owner overview, Operators, Client accounts, Team and permissions, and Audit activity. Choose an operator with Inspect. Status changes, metadata edits and entitlement withdrawals affect memory only. Reset or restart to discard them.</p><p>Viewer-only roles match the current application. No account creation, key management, real payments or external providers exist in this preview.</p></main>`,
);
function parseCookies(req) {
  return Object.fromEntries(
    (req.headers.cookie ?? "")
      .split(";")
      .map((c) => c.trim().split("="))
      .filter((c) => c.length === 2),
  );
}
async function body(req) {
  let bytes = 0,
    data = "";
  for await (const chunk of req) {
    bytes += chunk.length;
    if (bytes > 4096) throw new Error("Too large");
    data += chunk;
  }
  return data ? JSON.parse(data) : {};
}
function page(url, rows, limit) {
  const offset = Number(url.searchParams.get("offset") ?? 0);
  if (
    !Number.isInteger(offset) ||
    offset < 0 ||
    offset > 10000 ||
    Number(url.searchParams.get("limit") ?? limit) !== limit
  )
    return;
  return {
    rows: rows.slice(offset, offset + limit),
    pagination: { limit, offset, hasMore: offset + limit < rows.length },
  };
}
export async function startPreview() {
  let state = createState();
  const server = http.createServer((req, res) => {
    const send = (status, value, type = "application/json") => {
      res.writeHead(status, {
        "Content-Type": type,
        "Cache-Control": "no-store",
      });
      res.end(type === "application/json" ? JSON.stringify(value) : value);
    };
    void (async () => {
      res.setHeader("X-Content-Type-Options", "nosniff");
      res.setHeader("Referrer-Policy", "no-referrer");
      res.setHeader(
        "Content-Security-Policy",
        "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
      );
      if (
        req.headers.host !== `${HOST}:${PORT}` ||
        (req.headers.origin && req.headers.origin !== ORIGIN) ||
        (req.headers["sec-fetch-site"] &&
          !["same-origin", "none"].includes(req.headers["sec-fetch-site"]))
      )
        return send(403, { error: "Local demo only." });
      const url = new URL(req.url, ORIGIN);
      if (url.origin !== ORIGIN)
        return send(403, { error: "Local demo only." });
      if (!["GET", "POST", "PATCH"].includes(req.method))
        return send(405, { error: "Unsupported demo method." });
      if (req.method !== "GET" && req.headers.origin !== ORIGIN)
        return send(403, { error: "Local Origin required." });
      if (Number(req.headers["content-length"] ?? 0) > 4096)
        return send(413, { error: "Demo body too large." });
      if (req.headers["content-encoding"])
        return send(415, { error: "Compressed demo input unsupported." });
      const route = url.pathname,
        cookies = parseCookies(req);
      if (route === "/demo/reset" && req.method === "POST") {
        state = createState();
        res.setHeader(
          "Set-Cookie",
          cookieNames.map(
            (n) => `${n}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0`,
          ),
        );
        return send(
          200,
          html(
            '<script src="/demo-reset.js"></script><p>Resetting synthetic state…</p>',
          ),
          "text/html",
        );
      }
      if (route === "/demo/owner" && req.method === "GET") {
        if (state.ownerSessions.size >= 100) state.ownerSessions.clear();
        const token = randomUUID();
        state.ownerSessions.set(token, randomBytes(32).toString("hex"));
        res.setHeader(
          "Set-Cookie",
          `${cookieNames[0]}=${token}; HttpOnly; SameSite=Strict; Path=/`,
        );
        return send(
          200,
          html(
            '<script src="/demo-access.js"></script><p>Opening simulated owner access…</p>',
          ),
          "text/html",
        );
      }
      if (route === "/demo-access.js" && req.method === "GET")
        return send(
          200,
          'sessionStorage.removeItem("vaultx-owner-closed");location.replace("/owner/");',
          "text/javascript",
        );
      if (route === "/demo-reset.js" && req.method === "GET")
        return send(
          200,
          'sessionStorage.removeItem("vaultx-owner-closed");location.replace("/");',
          "text/javascript",
        );
      if (route === "/demo.css" && req.method === "GET")
        return send(
          200,
          "body{margin:0;background:#0b1120;color:#e5eaf5;font:15px system-ui}a{color:#add4ff}.demo-banner{padding:12px;text-align:center;background:#30290e;color:#fff;font:14px system-ui}.demo-banner a{margin:0 8px}.demo-banner form{display:inline}.demo-banner button{margin:6px;background:#1c2942;color:#fff;border:1px solid #687a96;padding:7px;cursor:pointer}.demo-home{max-width:850px;margin:40px auto;padding:24px;line-height:1.8}",
          "text/css",
        );
      if (route === "/" && req.method === "GET")
        return send(200, home, "text/html");
      if (route.startsWith("/owner-api")) {
        const csrf = state.ownerSessions.get(cookies[cookieNames[0]]);
        if (!csrf)
          return send(401, {
            error: "Synthetic owner access required. Use the demo navigation.",
          });
        if (route === "/owner-api/auth/csrf" && req.method === "GET")
          return send(200, { csrfToken: csrf });
        if (req.method !== "GET" && req.headers["x-csrf-token"] !== csrf)
          return send(403, { error: "Invalid demo CSRF." });
        if (route === "/owner-api/auth/me" && req.method === "GET")
          return send(200, {
            owner: OWNER,
            permissions: [
              "platform.clients.read",
              "platform.clients.manage",
              "platform.audit.read",
            ],
          });
        if (route === "/owner-api/auth/logout" && req.method === "POST") {
          state.ownerSessions.delete(cookies[cookieNames[0]]);
          res.setHeader(
            "Set-Cookie",
            `${cookieNames[0]}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`,
          );
          res.writeHead(204, { "Cache-Control": "no-store" });
          return res.end();
        }
        if (route === "/owner-api/clients" && req.method === "GET") {
          const result = page(url, state.operators, 20);
          return result
            ? send(200, {
                operators: result.rows,
                pagination: result.pagination,
              })
            : send(400, { error: "Invalid demo page." });
        }
        if (route === "/owner-api/audit" && req.method === "GET") {
          const result = page(url, state.audit, 20);
          return result
            ? send(200, { events: result.rows, pagination: result.pagination })
            : send(400, { error: "Invalid demo page." });
        }
        const match = /^\/owner-api\/clients\/([a-f0-9-]+)(.*)$/.exec(route);
        const operator = state.operators.find((o) => o.id === match?.[1]);
        if (!operator) return send(404, { error: "Demo client not found." });
        const suffix = match[2];
        if (suffix === "" && req.method === "GET")
          return send(200, { operator });
        if (suffix === "/members" && req.method === "GET") {
          const result = page(
            url,
            state.members.filter((m) => m.operatorId === operator.id),
            20,
          );
          return result
            ? send(200, {
                operatorId: operator.id,
                members: result.rows,
                pagination: result.pagination,
              })
            : send(400, { error: "Invalid demo page." });
        }
        const withdrawal =
          /^\/entitlements\/(client\.payments\.read|client\.status\.read)\/withdraw$/.exec(
            suffix,
          );
        if (
          (suffix === "" && req.method === "PATCH") ||
          (withdrawal && req.method === "POST")
        ) {
          const value = await body(req);
          if (value.expectedVersion !== operator.version)
            return send(409, { error: "Demo revision changed. Reload." });
          const time = new Date().toISOString();
          if (withdrawal) {
            const permission = withdrawal[1],
              ceiling = state.ceilings.get(operator.id);
            if (!ceiling.has(permission))
              return send(409, {
                error: "Demo entitlement already withdrawn.",
              });
            ceiling.delete(permission);
            for (const member of state.members.filter(
              (m) => m.operatorId === operator.id,
            )) {
              for (const grant of member.grants)
                if (grant.permission === permission && !grant.revokedAt)
                  grant.revokedAt = time;
              member.authorizationVersion++;
            }
          } else {
            if (
              Object.keys(value).some(
                (k) => !["expectedVersion", "name", "status"].includes(k),
              ) ||
              (value.name === undefined && value.status === undefined) ||
              (value.name !== undefined &&
                (typeof value.name !== "string" ||
                  !value.name.trim() ||
                  value.name.length > 120)) ||
              (value.status !== undefined &&
                !["active", "suspended"].includes(value.status))
            )
              return send(400, { error: "Invalid demo update." });
            if (value.name !== undefined) operator.name = value.name.trim();
            if (value.status !== undefined) {
              operator.status = value.status;
              if (value.status === "suspended")
                for (const member of state.members.filter(
                  (m) => m.operatorId === operator.id,
                ))
                  for (const grant of member.grants)
                    if (!grant.revokedAt) grant.revokedAt = time;
            }
          }
          operator.version++;
          record(
            state,
            withdrawal ? "entitlements.withdraw" : "operators.update",
            operator,
          );
          return send(200, { operator });
        }
        return send(405, { error: "Demo operation not available." });
      }
      if (route.startsWith("/dashboard-api")) {
        if (route === "/dashboard-api/auth/csrf" && req.method === "GET")
          return send(200, { csrfToken: "0".repeat(64) });
        if (route === "/dashboard-api/auth/login" && req.method === "POST") {
          await body(req);
          if (state.clientSessions.size >= 100) state.clientSessions.clear();
          const token = randomUUID();
          state.clientSessions.add(token);
          res.setHeader(
            "Set-Cookie",
            `${cookieNames[1]}=${token}; HttpOnly; SameSite=Strict; Path=/`,
          );
          return send(200, { authenticated: true, csrfToken: "0".repeat(64) });
        }
        if (
          !state.clientSessions.has(cookies[cookieNames[1]]) ||
          state.operators[0].status !== "active"
        )
          return send(401, {
            error: "Demo session unavailable. Reset demo state.",
          });
        if (route === "/dashboard-api/auth/logout" && req.method === "POST") {
          state.clientSessions.delete(cookies[cookieNames[1]]);
          res.writeHead(204, { "Cache-Control": "no-store" });
          return res.end();
        }
        if (req.method !== "GET")
          return send(405, { error: "Payment demo is read only." });
        if (route === "/dashboard-api/auth/me")
          return send(200, {
            user: { id: id(7000), username: "demo.client.viewer" },
            operator: { id: state.operators[0].id },
            role: "viewer",
          });
        const permission =
          route === "/dashboard-api/status" ? READS[1] : READS[0];
        if (
          !state.ceilings.get(state.operators[0].id).has(permission) ||
          !state.members
            .find(
              (m) =>
                m.operatorId === state.operators[0].id && m.status === "active",
            )
            ?.grants.some((g) => g.permission === permission && !g.revokedAt)
        )
          return send(403, {
            error: "Demo read entitlement withdrawn. Reset demo state.",
          });
        if (route === "/dashboard-api/status")
          return send(200, {
            status: "ok",
            gateway: "ok",
            database: "reachable",
            provider: "simulator",
            realPaymentsEnabled: false,
          });
        if (route === "/dashboard-api/payments") {
          const rows = state.payments.filter(
            (p) =>
              (!url.searchParams.get("status") ||
                p.status === url.searchParams.get("status")) &&
              (!url.searchParams.get("currency") ||
                p.currency === url.searchParams.get("currency")),
          );
          const result = page(url, rows, 10);
          return result
            ? send(200, {
                payments: result.rows,
                pagination: result.pagination,
              })
            : send(400, { error: "Invalid demo page." });
        }
        const payment = state.payments.find(
          (p) => route === "/dashboard-api/payments/" + p.id,
        );
        return payment
          ? send(200, payment)
          : send(404, { error: "Demo payment not found." });
      }
      if (req.method !== "GET")
        return send(405, { error: "No real API exists in this preview." });
      let filename;
      try {
        const decoded = decodeURIComponent(route);
        filename = path.resolve(PUBLIC, "." + decoded);
        if (!filename.startsWith(PUBLIC + path.sep))
          throw new Error("Not public");
      } catch {
        return send(404, { error: "Not found." });
      }
      if (route === "/dashboard/")
        filename = path.join(PUBLIC, "dashboard/index.html");
      if (route === "/owner/") filename = path.join(PUBLIC, "owner/owner.html");
      if (![".html", ".js", ".css"].includes(path.extname(filename)))
        return send(404, { error: "Not found." });
      try {
        let data = await readFile(filename);
        const ext = path.extname(filename);
        if (ext === ".html")
          data = Buffer.from(
            data
              .toString()
              .replace(
                "</head>",
                '<link rel="stylesheet" href="/demo.css"></head>',
              )
              .replace("<body>", "<body>" + navigation),
          );
        send(
          200,
          data,
          {
            ".html": "text/html",
            ".js": "text/javascript",
            ".css": "text/css",
          }[ext],
        );
      } catch {
        send(404, { error: "Not found." });
      }
    })().catch(() => {
      if (!res.headersSent) send(400, { error: "Invalid local demo request." });
      else res.end();
    });
  });
  server.requestTimeout = 5000;
  server.headersTimeout = 6000;
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(PORT, HOST, resolve);
  });
  return server;
}
if (
  process.argv[1] &&
  pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url
) {
  if (process.versions.node.split(".")[0] !== "24") {
    process.stderr.write("Install Node.js 24 LTS for this preview.\n");
    process.exitCode = 1;
  } else
    await startPreview()
      .then(() =>
        process.stdout.write(
          `VaultX Pay PREVIEW V2 — SIMULATED ONLY\nOpen ${ORIGIN}/\nNo database, gateway, credential input or real payments. Ctrl+C to stop.\n`,
        ),
      )
      .catch(() => {
        process.stderr.write(
          "Preview could not bind 127.0.0.1:4174. Close any previous preview and try again.\n",
        );
        process.exitCode = 1;
      });
}
