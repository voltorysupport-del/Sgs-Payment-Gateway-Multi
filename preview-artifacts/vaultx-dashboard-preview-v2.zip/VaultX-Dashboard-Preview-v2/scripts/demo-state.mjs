// Disposable synthetic fixtures only. No database, environment files or real API.
export const id = (n) =>
  `10000000-0000-4000-8000-${String(n).padStart(12, "0")}`;
export const READS = ["client.payments.read", "client.status.read"];
export const OWNER = { id: id(9000), username: "demo.gateway.owner" };
export function createState() {
  const names = [
    "Northstar Retail",
    "Lumen Studio",
    "Harbor Market",
    "Cedar Books",
    "Aurora Events",
    "Meadow Crafts",
    "Orion Travel",
    "Willow Cafe",
  ];
  const operators = Array.from({ length: 25 }, (_, i) => ({
    id: id(i + 1),
    name: `Demo ${names[i % names.length]} ${i + 1}`,
    code: `demo-client-${String(i + 1).padStart(2, "0")}`,
    status: i === 4 ? "suspended" : "active",
    version: 1,
  }));
  const members = operators.flatMap((operator, index) =>
    Array.from({ length: 3 }, (_, j) => ({
      id: id(100 + index * 3 + j),
      operatorId: operator.id,
      status: j === 2 ? "disabled" : "active",
      role: "viewer",
      authorizationVersion: 1,
      grants: READS.map((permission, k) => ({
        id: id(1000 + index * 6 + j * 2 + k),
        permission,
        revokedAt:
          j === 2 || operator.status === "suspended"
            ? "2026-10-20T09:00:00.000Z"
            : null,
      })),
    })),
  );
  const payments = Array.from({ length: 34 }, (_, i) => ({
    id: id(5000 + i),
    amountMinor: [100, 2450, 8900, 15999, 125000][i % 5],
    currency: ["EUR", "USD", "GBP"][i % 3],
    status: ["succeeded", "pending", "succeeded", "failed", "cancelled"][i % 5],
    provider: "simulator",
    createdAt: new Date(Date.UTC(2026, 9, 26, 12) - i * 1800000).toISOString(),
    updatedAt: new Date(
      Date.UTC(2026, 9, 26, 12, 5) - i * 1800000,
    ).toISOString(),
  }));
  const audit = Array.from({ length: 27 }, (_, i) => ({
    id: id(8000 + i),
    actorId: OWNER.id,
    action: ["operators.detail", "members.list", "operators.update"][i % 3],
    operatorId: operators[i % operators.length].id,
    occurredAt: new Date(Date.UTC(2026, 9, 26, 13) - i * 3600000).toISOString(),
    summary: { simulated: true },
  }));
  return {
    operators,
    members,
    payments,
    audit,
    ceilings: new Map(operators.map((o) => [o.id, new Set(READS)])),
    ownerSessions: new Map(),
    clientSessions: new Set(),
  };
}
export function record(state, action, operator) {
  state.audit.unshift({
    id: id(10000 + state.audit.length),
    actorId: OWNER.id,
    action,
    operatorId: operator.id,
    occurredAt: new Date().toISOString(),
    summary: { simulated: true, version: operator.version },
  });
}
